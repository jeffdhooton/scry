<?php

declare(strict_types=1);

namespace ScipPhp\Types\Internal;

use Override;

final readonly class MixedIterableType implements IterableType
{
    /** @param  non-empty-array<array-key, Type>  $types */
    public function __construct(private array $types)
    {
    }

    /** @inheritDoc */
    #[Override]
    public function flatten(): array
    {
        return [];
    }

    #[Override]
    public function valueType(int|string|null $key): ?Type
    {
        if ($key === null) {
            return null;
        }
        return $this->types[$key] ?? null;
    }
}
